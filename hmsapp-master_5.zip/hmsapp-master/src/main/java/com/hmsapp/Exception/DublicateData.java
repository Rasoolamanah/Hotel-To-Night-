package com.hmsapp.Exception;


public class DublicateData extends RuntimeException{
    public DublicateData(String message) {
        super(message);
    }

}
